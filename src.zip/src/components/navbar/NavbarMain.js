import React from 'react'
import SubHeader from './SubHeader'
import Navbar from './Navbar'
import NavbarBotton from './NavbarBotton'

function NavbarMain() {
  return (
    <>
      <SubHeader />
      <Navbar />
      <NavbarBotton />
    </>
  )
}

export default NavbarMain