export const PRODUCTS = [
  {
    _id: "pro-1",
    title: "Lenovo thinkplus lp12 simsiz quloqchinlari, TWS",
    price: 199_000,
    category: "texnika",
    url: ["https://img.gkbcdn.com/p/2022-02-18/Lenovo-Thinkplus-XT95Pro-TWS-Wireless-Earphone-Luminous-Black-496699-0._w500_p1_.jpg"],
    desc: "lorem ipsum dolor"
  },
  {
    _id: "pro-2",
    title: "Geympad Sony DualSense simsiz, PlayStation 5 uchun",
    price: 869_000,
    category: "texnika",
    url: ["https://images.uzum.uz/clir1ql6sfhjvlnagn0g/t_product_540_high.jpg#1701443777409"],
    desc: "lorem ipsum dolor"
  },
  {
    _id: "pro-3",
    title: "Kir yuvish kukuni Oila tanlovi, 3 kg, Ayoz tazeligi, Avtomat",
    price: 42_000,
    category: "hojalik-tovarlari",
    url: ["https://images.uzum.uz/clb1d15ennt861ipub40/t_product_540_high.jpg#1701443913235"],
    desc: "lorem ipsum dolor"
  },
  {
    _id: "pro-4",
    title: "Ryukzak eko-charmdan, uniseks, universal",
    price: 249_000,
    category: "maktab",
    url: ["https://images.uzum.uz/cj9n9cjk9fq5pecuq1ng/original.jpg"],
    desc: "lorem ipsum dolor"
  },
  {
    _id: "pro-5",
    title: "Mikser Braun HM1070WH",
    price: 798_000,
    category: "texnika",
    url: ["https://images.uzum.uz/cjjj0kkjvf2ofbh7oh5g/original.jpg"],
    desc: "lorem ipsum dolor"
  },
  {
    _id: "pro-6",
    title: "Go'sht maydalagich Ardesto MGL-1790R- 1700Вт/1.6 kg-min / pomidor, sharbat / qora",
    price: 699_000,
    category: "oshxona",
    url: ["https://images.uzum.uz/ck58ll4jvf2qegt46pjg/original.jpg"],
    desc: "lorem ipsum dolor"
  },
  {
    _id: "pro-7",
    title: "Dazmol Haley HY-274",
    price: 275_000,
    category: "texnika",
    url: ["https://images.uzum.uz/cjnddisvutv1g2rj4mvg/original.jpg"],
    desc: "lorem ipsum dolor"
  },
]

export default PRODUCTS