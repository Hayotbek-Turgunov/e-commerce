import React from 'react'

function Wishies() {
  return (
    <div>Wishies</div>
  )
}

export default Wishies